import { useState, useEffect, createContext, useContext } from "react";

// ─── Theme System ───
const DARK = {
  bg: "#111", surface: "#1a1a1a", card: "#222", cardHover: "#2a2a2a",
  border: "#333", borderLight: "#444", borderActive: "#888",
  text: "#e0e0e0", textMuted: "#888", textDim: "#555",
  primaryBg: "#e0e0e0", primaryText: "#111",
  nfcBg: "rgba(17,17,17,0.92)",
  badge: "#2a2a2a", badgeBorder: "#444", badgeText: "#aaa",
};
const LIGHT = {
  bg: "#f5f5f5", surface: "#ffffff", card: "#eaeaea", cardHover: "#e0e0e0",
  border: "#d0d0d0", borderLight: "#bbb", borderActive: "#666",
  text: "#1a1a1a", textMuted: "#666", textDim: "#999",
  primaryBg: "#1a1a1a", primaryText: "#f5f5f5",
  nfcBg: "rgba(255,255,255,0.92)",
  badge: "#e8e8e8", badgeBorder: "#ccc", badgeText: "#777",
};
const ThemeContext = createContext(LIGHT);
function useC() { return useContext(ThemeContext); }
let C = LIGHT;

// ─── Badge component for vitamin/ingredient codes ───
// ─── Badge component — vitamin codes (compact, clinical) vs botanical/fruit (warmer, organic) ───
const BOTANICAL_CODES = new Set(["Ginger", "Mint", "Berry", "Chamomile", "Hibiscus", "Pomegranate", "Peach", "Açaí", "Blackcurrant"]);
function Badge({ label }) {
  const C = useC();
  const isBotanical = BOTANICAL_CODES.has(label);
  return (
    <span style={{ display: "inline-block", padding: "1px 6px", background: isBotanical ? "transparent" : C.badge, border: `1px solid ${isBotanical ? C.borderLight : C.badgeBorder}`, borderRadius: isBotanical ? 8 : 4, fontSize: 8, fontWeight: isBotanical ? 600 : 700, fontStyle: isBotanical ? "italic" : "normal", color: isBotanical ? C.textMuted : C.badgeText, letterSpacing: "0.3px", lineHeight: "14px" }}>{isBotanical ? `${label}` : label}</span>
  );
}
function BadgeGroup({ codes }) {
  return (
    <div style={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
      {codes.map(c => <Badge key={c} label={c} />)}
    </div>
  );
}

// ─── Data Model: 9 BiBs ───
// 3 Boosts (independent BiBs)
const BOOSTS = [
  { id: "collagen", name: "Glow & Move Freely", ingredient: "Collagen", codes: ["Collagen"],
    benefit: "Supports skin elasticity and joint recovery",
    dispenseBenefit: "Supporting your skin and joints with Collagen",
    glassLabel: "Collagen", color: "#7a6e5e", height: 18 },
  { id: "protein", name: "Get Stronger After Every Session", ingredient: "Protein", codes: ["Protein"],
    benefit: "Rebuilds muscles after physical activity",
    dispenseBenefit: "Rebuilding your muscles with Protein",
    glassLabel: "Protein", color: "#6a7a6e", height: 20 },
  { id: "electrolytes", name: "Replenish & Rehydrate", ingredient: "Electrolytes", codes: ["Electrolytes"],
    benefit: "Replenishes minerals lost through sweat and activity",
    dispenseBenefit: "Rehydrating you with Electrolytes",
    glassLabel: "Electrolytes", color: "#5e6e7a", height: 16 },
];

// 6 Flavors (each carries its own vitamin profile + botanical/fruit ingredients)
const FLAVORS = [
  {
    id: "lemon", name: "Lemon", fn: "Immunity", tag: "Zero sugar",
    codes: ["C", "D", "B12", "Ginger"],
    glassLabel: "Vitamin C · D · Ginger",
    vitamins: [
      { code: "C", benefit: "Fights fatigue with Vitamin C" },
      { code: "D", benefit: "Strengthens natural defenses with Vitamin D" },
      { code: "B12", benefit: "Supports steady energy with B12" },
      { code: "Ginger", benefit: "Warming ginger to support your gut and immunity", botanical: true },
    ],
    dispenseBenefit: "Supporting your immune system with Vitamin C, D & ginger",
    layerColor: "#d4b84a", layerHeight: 32,
  },
  {
    id: "red_fruits_mint", name: "Red Fruits & Mint", fn: "Focus", tag: "Zero sugar",
    codes: ["D", "Caffeine", "Mint", "Berry"],
    glassLabel: "Vitamin D · Caffeine · Mint",
    vitamins: [
      { code: "D", benefit: "Keeps your mind sharp with Vitamin D" },
      { code: "Caffeine", benefit: "Sustained alertness with natural caffeine" },
      { code: "Mint", benefit: "Mint for mental clarity and a fresh head", botanical: true },
      { code: "Berry", benefit: "Antioxidant-rich berries to protect while you perform", botanical: true },
    ],
    dispenseBenefit: "Sharpening your focus with Vitamin D, caffeine & mint",
    layerColor: "#b85060", layerHeight: 26,
  },
  {
    id: "mango_guava", name: "Mango Guava", fn: "Unwind", tag: "Zero sugar",
    codes: ["C", "B5", "B6", "B12", "Chamomile"],
    glassLabel: "B-Complex · C · Chamomile",
    vitamins: [
      { code: "C", benefit: "Protects your body while you relax with Vitamin C" },
      { code: "B5", benefit: "Eases mental tension with B5" },
      { code: "B6", benefit: "Helps regulate your mood with B6" },
      { code: "B12", benefit: "Supports recovery from a long day with B12" },
      { code: "Chamomile", benefit: "Chamomile to calm your nervous system naturally", botanical: true },
    ],
    dispenseBenefit: "Helping you unwind with B-Complex, Vitamin C & chamomile",
    layerColor: "#d4a050", layerHeight: 36,
  },
  {
    id: "raspberry_pomegranate", name: "Raspberry & Pomegranate", fn: "Balance", tag: "Zero sugar",
    codes: ["E", "B5", "B6", "B12", "Hibiscus", "Pomegranate"],
    glassLabel: "B-Complex · E · Hibiscus",
    vitamins: [
      { code: "E", benefit: "Protects your cells from daily wear with Vitamin E" },
      { code: "B5", benefit: "Keeps your metabolism in rhythm with B5" },
      { code: "B6", benefit: "Balances your energy with B6" },
      { code: "B12", benefit: "Fuels steady, all-day performance with B12" },
      { code: "Pomegranate", benefit: "Pomegranate — packed with polyphenols for cellular health", botanical: true },
      { code: "Hibiscus", benefit: "Hibiscus extract to support healthy circulation", botanical: true },
    ],
    dispenseBenefit: "Keeping you balanced with Vitamin E, B-Complex & pomegranate",
    layerColor: "#9a5a7a", layerHeight: 36,
  },
  {
    id: "peach", name: "Peach", fn: "Glow", tag: "Zero sugar",
    codes: ["B3", "C", "Peach"],
    glassLabel: "Vitamin B3 · C · Peach",
    vitamins: [
      { code: "B3", benefit: "Nourishes your skin from the inside with B3" },
      { code: "C", benefit: "Supports collagen for stronger skin with Vitamin C" },
      { code: "Peach", benefit: "Peach — naturally rich in skin-loving vitamins A & E", botanical: true },
    ],
    dispenseBenefit: "Nourishing your skin with Vitamin B3, C & peach extract",
    layerColor: "#e0a070", layerHeight: 26,
  },
  {
    id: "blackcurrant_acai", name: "Blackcurrant Açaí", fn: "Thrive", tag: "Zero sugar",
    codes: ["B1", "B3", "Açaí", "Blackcurrant"],
    glassLabel: "Vitamin B1 · B3 · Açaí",
    vitamins: [
      { code: "B1", benefit: "Keeps your energy systems firing with B1" },
      { code: "B3", benefit: "Converts food into fuel you feel with B3" },
      { code: "Açaí", benefit: "Açaí — one of nature's most antioxidant-dense fruits", botanical: true },
      { code: "Blackcurrant", benefit: "Blackcurrant for natural Vitamin C and anthocyanins", botanical: true },
    ],
    dispenseBenefit: "Fuelling your day with Vitamin B1, B3, açaí & blackcurrant",
    layerColor: "#6a5a8a", layerHeight: 26,
  },
];

const WATER_TYPES = [
  { id: "still", label: "Still" },
  { id: "sparkling", label: "Sparkling" },
  { id: "chilled", label: "Chilled" },
  { id: "room_temp", label: "Room Temp" },
];

const VOLUMES = [
  { ml: 200, label: "Cup" },
  { ml: 500, label: "Bottle" },
  { ml: 1000, label: "Large" },
];

// ─── Screensaver: warm + function-aware (Ritual meets Moon Juice) ───
const SCREENSAVER_SLIDES = [
  { type: "emotion", prefix: "Your daily dose of", keyword: "focus", sub: "Vitamin D & natural caffeine, in a drink you'll actually crave." },
  { type: "live", big: "284 drinks crafted here today", sub: "Most popular: Protein boost + Lemon Immunity" },
  { type: "emotion", prefix: "A gentler kind of", keyword: "energy", sub: "B-Complex vitamins that work with your body, not against it." },
  { type: "live", big: "Trending this afternoon", sub: "Unwind · Mango Guava · Vitamin C & B-Complex" },
  { type: "emotion", prefix: "Glow from the", keyword: "inside", sub: "Vitamin B3 & C — your skin's favourite afternoon ritual." },
  { type: "live", big: "52 people added a recovery boost today", sub: "Protein + Electrolytes was the top combo" },
];

// ─── Suggested drinks ───
const SUGGESTED_DRINKS = {
  community: [
    { label: "Most popular right now", sub: "Ordered 18× this morning", flavorId: "lemon", boostIds: ["protein"], waterType: "chilled", volume: 500 },
    { label: "Afternoon favourite", sub: "Top pick after 2pm here", flavorId: "mango_guava", boostIds: [], waterType: "sparkling", volume: 200 },
    { label: "Trending this week", sub: "Rising fast across machines", flavorId: "peach", boostIds: ["collagen"], waterType: "chilled", volume: 500 },
  ],
  app: [
    { label: "Based on your sleep score", sub: "Oura: 5.8h sleep — low recovery", flavorId: "red_fruits_mint", boostIds: ["protein", "electrolytes"], waterType: "chilled", volume: 500 },
    { label: "Post-workout recovery", sub: "Whoop: 45min strength session", flavorId: "lemon", boostIds: ["protein", "electrolytes"], waterType: "chilled", volume: 500 },
  ],
};

// ═══════════ SHARED COMPONENTS ═══════════
function NfcStrip() {
  const C = useC();
  return (
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "7px 28px", background: C.nfcBg, borderTop: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, zIndex: 10 }}>
      <span style={{ fontSize: 13, opacity: 0.4 }}>📱</span>
      <span style={{ fontSize: 10, color: C.textDim, fontWeight: 500 }}>Have the app? Tap your phone — pour in 5 seconds.</span>
    </div>
  );
}

// Cross-section glass — ingredient names as labels, no quantities
function GlassViz({ boostLayers, flavorObj, waterType, volume, animPhase, fillProgress }) {
  const C = useC();
  const maxH = 220, glassW = 120;
  const bLayers = boostLayers || [];
  const fLayer = flavorObj ? { label: flavorObj.glassLabel, color: flavorObj.layerColor, height: flavorObj.layerHeight } : null;
  const allLayers = [...bLayers.map(b => ({ label: b.glassLabel, color: b.color, height: b.height })), ...(fLayer ? [fLayer] : [])];
  const totalIngH = allLayers.reduce((s, l) => s + l.height, 0);
  const waterBase = (animPhase >= 1 || bLayers.length > 0 || fLayer) ? 20 : 0;
  const rem = maxH - totalIngH - waterBase;
  const waterFill = fillProgress != null ? (rem * Math.min(fillProgress, 100) / 100) : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
      {volume && <div style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px" }}>{volume} ml · {waterType?.replace("_", " ") || "water"}</div>}
      <div style={{ width: glassW + 14, height: maxH + 24, position: "relative", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
        <div style={{ width: glassW, height: maxH, border: `2px solid ${C.borderLight}`, borderTop: "none", borderRadius: "0 0 14px 14px", position: "relative", overflow: "hidden", background: `${C.surface}88` }}>
          <div style={{ position: "absolute", top: -1, left: -5, right: -5, height: 3, background: C.borderLight, borderRadius: 2 }} />
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, background: `repeating-linear-gradient(0deg, transparent 0px, transparent 19px, ${C.border}22 19px, ${C.border}22 20px)`, pointerEvents: "none", zIndex: 1 }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, display: "flex", flexDirection: "column-reverse", zIndex: 2 }}>
            {waterBase > 0 && (bLayers.length > 0 || fLayer) && <div style={{ height: waterBase, background: `repeating-linear-gradient(0deg, ${C.border}44 0px, ${C.border}44 1px, transparent 1px, transparent 4px)`, transition: "height 0.6s", display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ fontSize: 7, color: C.textDim, fontWeight: 600 }}>WATER</span></div>}
            {bLayers.map((b, i) => (
              <div key={b.id + i} style={{ height: b.height, background: b.color, transition: "height 0.6s", transitionDelay: `${i * 0.15}s`, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                <span style={{ fontSize: 6, color: "#ddd", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.5px", whiteSpace: "nowrap", textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}>{b.glassLabel}</span>
              </div>
            ))}
            {fLayer && <div style={{ height: fLayer.height, background: `linear-gradient(180deg, ${fLayer.color}ee, ${fLayer.color})`, transition: "height 0.6s", transitionDelay: `${bLayers.length * 0.15}s`, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", borderTop: "1px solid rgba(255,255,255,0.1)" }}>
              <span style={{ fontSize: 6, color: "#fff", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.5px", whiteSpace: "nowrap", textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}>{fLayer.label}</span>
            </div>}
            {waterFill > 0 && <div style={{ height: waterFill, background: `repeating-linear-gradient(0deg, ${C.border}22 0px, ${C.border}22 1px, transparent 1px, transparent 5px)`, transition: "height 0.3s linear", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>{waterFill > 14 && <span style={{ fontSize: 6, color: C.textDim, fontWeight: 600, textTransform: "uppercase" }}>{waterType?.replace("_", " ") || "WATER"}</span>}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}

// Benefit cards — badges for codes, no dosages
function BenefitCards({ boostLayers, flavorObj }) {
  const C = useC();
  const hasBotanicals = flavorObj?.vitamins?.some(v => v.botanical);
  return (
    <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 4 }}>
      {boostLayers.length > 0 && <>
        <div style={{ fontSize: 8, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", textAlign: "center", marginBottom: 2 }}>Your boosts</div>
        {boostLayers.map(b => (
          <div key={b.id} style={{ display: "flex", gap: 6, alignItems: "flex-start", padding: "5px 8px", background: C.bg, border: `1px solid ${C.borderActive}`, borderRadius: 6 }}>
            <div style={{ width: 14, height: 14, borderRadius: 3, border: `1px solid ${C.borderActive}`, background: C.card, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}><span style={{ fontSize: 8, fontWeight: 800, color: C.text }}>+</span></div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 2 }}><span style={{ fontSize: 10, fontWeight: 700, color: C.text }}>{b.name}</span></div>
              <div style={{ fontSize: 9, color: C.textMuted, lineHeight: "12px", marginBottom: 3 }}>{b.benefit}</div>
              <BadgeGroup codes={b.codes} />
            </div>
          </div>
        ))}
      </>}
      {flavorObj && <>
        <div style={{ fontSize: 8, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", textAlign: "center", marginTop: boostLayers.length > 0 ? 4 : 0, marginBottom: 2 }}>{flavorObj.fn}{hasBotanicals ? " — vitamins & botanicals" : " vitamins"}</div>
        {flavorObj.vitamins.map((v, i) => (
          <div key={v.code + i} style={{ display: "flex", gap: 6, alignItems: "center", padding: "5px 8px", background: C.bg, border: `1px solid ${v.botanical ? C.borderLight : C.border}`, borderRadius: 6 }}>
            <Badge label={v.code} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 9, color: C.textMuted, lineHeight: "12px", fontStyle: v.botanical ? "italic" : "normal" }}>{v.benefit}</div>
            </div>
          </div>
        ))}
      </>}
    </div>
  );
}

// ═══════════ SCREENSAVER ═══════════
function Screensaver({ onTap }) {
  const C = useC();
  const [idx, setIdx] = useState(0);
  const [fade, setFade] = useState(true);
  const slide = SCREENSAVER_SLIDES[idx];
  useEffect(() => { const t = setInterval(() => { setFade(false); setTimeout(() => { setIdx(i => (i + 1) % SCREENSAVER_SLIDES.length); setFade(true); }, 400); }, 5000); return () => clearInterval(t); }, []);

  return (
    <div onClick={onTap} style={{ width: "100%", height: "100%", background: C.bg, display: "flex", cursor: "pointer", fontFamily: "system-ui, sans-serif", overflow: "hidden", position: "relative" }}>
      <div style={{ width: "50%", display: "flex", flexDirection: "column", justifyContent: "center", padding: "48px 40px", borderRight: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "2px", marginBottom: 32 }}>AQUABLU BOLD</div>
        <div style={{ opacity: fade ? 1 : 0, transition: "opacity 0.4s" }}>
          {slide.type === "emotion" ? (
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 16, fontWeight: 400, color: C.textMuted, marginBottom: 4 }}>{slide.prefix}</div>
              <div style={{ fontSize: 48, fontWeight: 900, color: C.text, lineHeight: 1.0, textTransform: "lowercase" }}>{slide.keyword}.</div>
            </div>
          ) : (
            <>
              <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>Live from this machine</div>
              <div style={{ fontSize: 28, fontWeight: 800, color: C.text, lineHeight: 1.15, marginBottom: 10 }}>{slide.big}</div>
            </>
          )}
          {slide.sub && <div style={{ fontSize: 14, color: C.textMuted, fontWeight: 400, lineHeight: "20px" }}>{slide.sub}</div>}
        </div>
        <div style={{ display: "flex", gap: 5, marginTop: 28 }}>
          {SCREENSAVER_SLIDES.map((_, i) => <div key={i} style={{ width: i === idx ? 20 : 5, height: 3, borderRadius: 2, background: i === idx ? C.textMuted : C.border, transition: "all 0.4s" }} />)}
        </div>
        <div style={{ marginTop: 40, fontSize: 13, color: C.textDim, fontWeight: 500 }}>Tap anywhere to start →</div>
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", opacity: fade ? 1 : 0, transition: "opacity 0.4s" }}>
        {slide.type === "live" ? (
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 64, fontWeight: 900, color: C.text, letterSpacing: "-2px", lineHeight: 1 }}>{slide.big.match(/\d+/)?.[0] || ""}</div>
            <div style={{ fontSize: 13, color: C.textMuted, marginTop: 8 }}>drinks crafted</div>
          </div>
        ) : (
          <div style={{ width: 100, height: 180, border: `2px solid ${C.borderLight}`, borderTop: "none", borderRadius: "0 0 12px 12px", position: "relative", overflow: "hidden", background: `${C.surface}88` }}>
            <div style={{ position: "absolute", top: -1, left: -5, right: -5, height: 3, background: C.borderLight, borderRadius: 2 }} />
            <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "45%", background: `repeating-linear-gradient(0deg, ${C.border}44 0px, ${C.border}44 1px, transparent 1px, transparent 6px)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ fontSize: 9, color: C.textDim, fontWeight: 600 }}>YOUR DRINK</span>
            </div>
          </div>
        )}
      </div>
      <NfcStrip />
    </div>
  );
}

// ═══════════ ENTRY CHOICE ═══════════
function EntryChoice({ onCraft, onSuggested, onQuickSelect }) {
  const C = useC();
  return (
    <div style={{ width: "100%", height: "100%", background: C.bg, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "system-ui, sans-serif", gap: 14, padding: 40 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "2px" }}>AQUABLU BOLD</div>
      <div style={{ fontSize: 28, fontWeight: 800, color: C.text, textAlign: "center" }}>How would you like to start?</div>
      <div style={{ display: "flex", gap: 14, marginTop: 8 }}>
        <button onClick={onCraft} style={{ fontFamily: "system-ui", background: C.primaryBg, color: C.primaryText, border: "none", borderRadius: 14, padding: "24px 22px", width: 240, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: 10, cursor: "pointer" }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, border: "1px solid rgba(128,128,128,0.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>✦</div>
          <div style={{ fontSize: 15, fontWeight: 700 }}>What does your body need?</div>
          <div style={{ fontSize: 12, opacity: 0.7, lineHeight: "16px" }}>Pick your boosts, choose a flavour, pour</div>
        </button>
        <button onClick={onSuggested} style={{ fontFamily: "system-ui", background: C.card, color: C.text, border: `1px solid ${C.border}`, borderRadius: 14, padding: "24px 22px", width: 240, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: 10, cursor: "pointer" }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, border: `1px solid ${C.borderLight}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, color: C.textMuted }}>★</div>
          <div style={{ fontSize: 15, fontWeight: 700 }}>Suggested for you</div>
          <div style={{ fontSize: 12, color: C.textMuted, lineHeight: "16px" }}>See what's popular at this machine right now</div>
        </button>
      </div>
      <button style={{ fontFamily: "system-ui", background: C.surface, color: C.text, border: `1px solid ${C.borderLight}`, borderRadius: 14, padding: "16px 28px", width: 494, display: "flex", alignItems: "center", justifyContent: "center", gap: 14, cursor: "pointer", marginTop: 2 }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, border: `1px solid ${C.borderLight}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>📱</div>
        <div style={{ textAlign: "left" }}>
          <div style={{ fontSize: 14, fontWeight: 700 }}>Tap your phone for a personalised drink</div>
          <div style={{ fontSize: 11, color: C.textMuted, marginTop: 1 }}>Connect your health data and pour in 5 seconds</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, marginLeft: "auto", flexShrink: 0 }}><div style={{ width: 28, height: 2, background: C.borderLight, borderRadius: 1 }} /><span style={{ fontSize: 8, fontWeight: 700, color: C.textDim, letterSpacing: "1px" }}>NFC</span></div>
      </button>
      <button onClick={onQuickSelect} style={{ fontFamily: "system-ui", background: "none", border: "none", color: C.textDim, fontSize: 13, fontWeight: 500, cursor: "pointer", marginTop: 2, padding: "8px 16px", textDecoration: "underline", textUnderlineOffset: "3px" }}>I already know what I want →</button>
    </div>
  );
}

// ═══════════ CRAFT BUILDER — 3 steps ═══════════
function CraftBuilder({ onDispense, onBack }) {
  const C = useC();
  const [step, setStep] = useState(0);
  const [boosts, setBoosts] = useState([]);
  const [flavorId, setFlavorId] = useState(null);
  const [waterType, setWaterType] = useState("chilled");
  const [volume, setVolume] = useState(500);

  const boostLayers = boosts.map(id => BOOSTS.find(b => b.id === id)).filter(Boolean);
  const flavorObj = FLAVORS.find(f => f.id === flavorId);
  const toggleBoost = (id) => setBoosts(s => s.includes(id) ? s.filter(x => x !== id) : s.length < 2 ? [...s, id] : s);

  const stepLabels = ["What does your body need?", "Now add your flavour", "How do you want it served?"];
  const canContinue = step === 0 ? true : step === 1 ? !!flavorId : true;

  return (
    <div style={{ width: "100%", height: "100%", background: C.bg, display: "flex", fontFamily: "system-ui, sans-serif", overflow: "hidden" }}>
      {/* Left — glass viz */}
      <div style={{ width: "40%", display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 14px", background: C.surface, overflow: "auto", borderRight: `1px solid ${C.border}` }}>
        {boosts.length === 0 && !flavorObj ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
            <GlassViz boostLayers={[]} flavorObj={null} waterType={waterType} volume={volume} animPhase={0} />
            <div style={{ fontSize: 11, color: C.textDim, marginTop: 8 }}>Pick boosts or a flavour<br />to start building your drink</div>
          </div>
        ) : (
          <>
            <GlassViz boostLayers={boostLayers} flavorObj={flavorObj} waterType={waterType} volume={volume} animPhase={step} />
            {flavorObj && <div style={{ marginTop: 5, padding: "4px 12px", background: C.bg, border: `1px solid ${C.borderActive}`, borderRadius: 100, fontSize: 10, fontWeight: 700, color: C.text }}>{flavorObj.name} — {flavorObj.fn}</div>}
            <div style={{ marginTop: 6, width: "100%" }}>
              <BenefitCards boostLayers={boostLayers} flavorObj={flavorObj} />
            </div>
          </>
        )}
      </div>
      {/* Right — controls */}
      <div style={{ width: "60%", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 28px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button onClick={step > 0 ? () => setStep(s => s - 1) : onBack} style={{ background: "none", border: "none", color: C.textMuted, cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "system-ui" }}>← Back</button>
          <div style={{ display: "flex", gap: 4 }}>{stepLabels.map((_, i) => <div key={i} style={{ width: i === step ? 24 : 8, height: 4, borderRadius: 2, background: i === step ? C.textMuted : i < step ? C.borderActive : C.border, transition: "all 0.3s" }} />)}</div>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px" }}>Step {step + 1} of 3</div>
        </div>
        <div style={{ flex: 1, padding: "14px 28px", overflow: "auto", paddingBottom: 10 }}>

          {/* STEP 0: Boosts — name + benefit + badge */}
          {step === 0 && <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: C.text, marginBottom: 3 }}>What does your body need?</div>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 16 }}>Add up to 2 boosts to supercharge your drink</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {BOOSTS.map(b => {
                const on = boosts.includes(b.id);
                return (
                  <button key={b.id} onClick={() => toggleBoost(b.id)} style={{ fontFamily: "system-ui", background: on ? C.card : "transparent", border: `1.5px solid ${on ? C.borderActive : C.border}`, borderRadius: 12, padding: "14px 16px", cursor: "pointer", textAlign: "left", transition: "all 0.15s", display: "flex", gap: 12, alignItems: "center" }}>
                    <div style={{ width: 36, height: 36, borderRadius: 8, border: `1.5px solid ${on ? C.borderActive : C.border}`, display: "flex", alignItems: "center", justifyContent: "center", background: on ? C.surface : "transparent", flexShrink: 0, transition: "all 0.15s" }}>
                      <span style={{ fontSize: 16, fontWeight: 800, color: on ? C.text : C.textDim }}>{on ? "✓" : "+"}</span>
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: on ? C.text : C.textMuted, marginBottom: 2 }}>{b.name}</div>
                      <div style={{ fontSize: 12, color: C.textMuted, lineHeight: "16px", marginBottom: 4 }}>{b.benefit}</div>
                      <BadgeGroup codes={b.codes} />
                    </div>
                  </button>
                );
              })}
            </div>
            {boosts.length === 0 && <div style={{ marginTop: 12, fontSize: 11, color: C.textDim, fontStyle: "italic", textAlign: "center" }}>Just a vitamin drink today? That's great too — continue to pick your flavour.</div>}
          </div>}

          {/* STEP 1: Flavor — hero name, function secondary, codes as badges */}
          {step === 1 && <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: C.text, marginBottom: 3 }}>Now add your flavour</div>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 16 }}>Every flavour comes loaded with vitamins</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 8 }}>
              {FLAVORS.map(f => {
                const on = flavorId === f.id;
                return (
                  <button key={f.id} onClick={() => setFlavorId(f.id)} style={{ fontFamily: "system-ui", background: on ? C.card : "transparent", border: `1.5px solid ${on ? C.borderActive : C.border}`, borderRadius: 12, padding: "12px 14px", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                    <div style={{ fontSize: 15, fontWeight: 700, color: on ? C.text : C.textMuted }}>{f.name}</div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: on ? C.text : C.textDim, marginTop: 3, display: "flex", alignItems: "center", gap: 4 }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: f.layerColor, flexShrink: 0 }} />
                      {f.fn}
                    </div>
                    <div style={{ marginTop: 5 }}><BadgeGroup codes={f.codes} /></div>
                    <div style={{ fontSize: 8, color: C.textDim, marginTop: 4 }}>{f.tag}</div>
                  </button>
                );
              })}
            </div>
          </div>}

          {/* STEP 2: Water + Volume */}
          {step === 2 && <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: C.text, marginBottom: 3 }}>How do you want it served?</div>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 20 }}>Almost there — pick your water and size</div>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>Water style</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6, marginBottom: 20 }}>
              {WATER_TYPES.map(w => <button key={w.id} onClick={() => setWaterType(w.id)} style={{ fontFamily: "system-ui", background: waterType === w.id ? C.card : "transparent", border: `1px solid ${waterType === w.id ? C.borderActive : C.border}`, borderRadius: 8, padding: "10px 8px", cursor: "pointer", fontSize: 13, fontWeight: waterType === w.id ? 700 : 500, color: waterType === w.id ? C.text : C.textMuted, transition: "all 0.12s", textAlign: "center" }}>{w.label}</button>)}
            </div>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 8 }}>Volume</div>
            <div style={{ display: "flex", gap: 10 }}>
              {VOLUMES.map(v => <button key={v.ml} onClick={() => setVolume(v.ml)} style={{ fontFamily: "system-ui", width: 64, height: 64, borderRadius: "50%", background: volume === v.ml ? C.card : "transparent", border: `1.5px solid ${volume === v.ml ? C.borderActive : C.border}`, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", transition: "all 0.12s" }}><span style={{ fontSize: 14, fontWeight: 700, color: volume === v.ml ? C.text : C.textMuted }}>{v.ml >= 1000 ? "1L" : v.ml}</span><span style={{ fontSize: 8, color: C.textDim }}>{v.label}</span></button>)}
            </div>
          </div>}
        </div>
        <div style={{ padding: "12px 28px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
          {step < 2 ? (
            <button onClick={() => { if (step === 1 && !flavorId) return; setStep(s => s + 1); }} disabled={step === 1 && !flavorId} style={{ fontFamily: "system-ui", background: canContinue ? C.primaryBg : C.card, color: canContinue ? C.primaryText : C.textDim, border: "none", borderRadius: 100, padding: "9px 30px", cursor: canContinue ? "pointer" : "default", fontSize: 12, fontWeight: 700, opacity: canContinue ? 1 : 0.4 }}>Continue →</button>
          ) : (
            <button onClick={() => onDispense({ boosts, boostLayers, flavor: flavorObj, waterType, volume })} style={{ fontFamily: "system-ui", background: C.primaryBg, color: C.primaryText, border: "none", borderRadius: 100, padding: "9px 30px", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>Dispense →</button>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════ SUGGESTED DRINK ═══════════
function SuggestedDrink({ onDispense, onBack }) {
  const C = useC();
  const [source, setSource] = useState("community");
  const [selected, setSelected] = useState(null);
  const suggestions = SUGGESTED_DRINKS[source];
  const buildConfig = (sug) => {
    const fl = FLAVORS.find(f => f.id === sug.flavorId);
    const bl = sug.boostIds.map(id => BOOSTS.find(b => b.id === id)).filter(Boolean);
    return { boosts: sug.boostIds, boostLayers: bl, flavor: fl, waterType: sug.waterType, volume: sug.volume };
  };
  const sel = selected !== null ? suggestions[selected] : null;
  const config = sel ? buildConfig(sel) : null;

  return (
    <div style={{ width: "100%", height: "100%", background: C.bg, display: "flex", fontFamily: "system-ui, sans-serif", overflow: "hidden" }}>
      <div style={{ width: "40%", display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 14px", background: C.surface, overflow: "auto", borderRight: `1px solid ${C.border}` }}>
        {!config ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
            <GlassViz boostLayers={[]} flavorObj={null} waterType="chilled" volume={500} animPhase={0} />
            <div style={{ fontSize: 11, color: C.textDim, marginTop: 8 }}>Select a suggestion to<br />preview your drink</div>
          </div>
        ) : (
          <>
            <GlassViz boostLayers={config.boostLayers} flavorObj={config.flavor} waterType={config.waterType} volume={config.volume} animPhase={2} />
            {config.flavor && <div style={{ marginTop: 5, padding: "4px 12px", background: C.bg, border: `1px solid ${C.borderActive}`, borderRadius: 100, fontSize: 10, fontWeight: 700, color: C.text }}>{config.flavor.name} — {config.flavor.fn}</div>}
            <div style={{ marginTop: 6, width: "100%" }}><BenefitCards boostLayers={config.boostLayers} flavorObj={config.flavor} /></div>
          </>
        )}
      </div>
      <div style={{ width: "60%", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 28px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", color: C.textMuted, cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "system-ui" }}>← Back</button>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px" }}>Suggested for you</div>
        </div>
        <div style={{ padding: "12px 28px 0" }}>
          <div style={{ display: "inline-flex", background: C.surface, borderRadius: 100, padding: 3, border: `1px solid ${C.border}` }}>
            {[{ id: "community", label: "Popular here", icon: "♺" }, { id: "app", label: "From your health data", icon: "♡" }].map(s => <button key={s.id} onClick={() => { setSource(s.id); setSelected(null); }} style={{ fontFamily: "system-ui", background: source === s.id ? C.card : "transparent", color: source === s.id ? C.text : C.textMuted, border: source === s.id ? `1px solid ${C.borderActive}` : "1px solid transparent", borderRadius: 100, padding: "8px 16px", cursor: "pointer", fontSize: 11, fontWeight: source === s.id ? 700 : 500, transition: "all 0.12s", whiteSpace: "nowrap" }}>{s.icon} {s.label}</button>)}
          </div>
        </div>
        <div style={{ flex: 1, padding: "12px 28px", overflow: "auto" }}>
          {source === "community" && <>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 10 }}>See what others are drinking right now</div>
            <div style={{ padding: "8px 12px", marginBottom: 10, background: C.surface, border: `1px dashed ${C.border}`, borderRadius: 9, opacity: 0.55 }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: C.textMuted }}>💡 With the app, we'd know your sleep and activity data</div>
              <div style={{ fontSize: 9, color: C.textDim, marginTop: 2 }}>and suggest a drink tailored to your actual day.</div>
            </div>
          </>}
          {source === "app" && <div style={{ padding: "8px 12px", marginBottom: 10, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 9, display: "flex", gap: 8, alignItems: "center" }}><span style={{ fontSize: 13 }}>📱</span><div><div style={{ fontSize: 10, fontWeight: 700, color: C.text }}>Connected via Oura Ring</div><div style={{ fontSize: 9, color: C.textDim }}>Synced 2h ago</div></div></div>}
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {suggestions.map((sug, i) => {
              const fl = FLAVORS.find(f => f.id === sug.flavorId);
              const bls = sug.boostIds.map(id => BOOSTS.find(b => b.id === id)).filter(Boolean);
              const active = selected === i;
              return (
                <button key={i} onClick={() => setSelected(i)} style={{ fontFamily: "system-ui", background: active ? C.card : "transparent", border: `1px solid ${active ? C.borderActive : C.border}`, borderRadius: 11, padding: "12px 14px", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 8 }}>
                    <div style={{ width: 26, height: 26, borderRadius: 6, background: C.surface, border: `1px solid ${C.borderLight}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, flexShrink: 0 }}>{source === "community" ? (i === 0 ? "🔥" : i === 1 ? "☀" : "📈") : (i === 0 ? "😴" : "💪")}</div>
                    <div><div style={{ fontSize: 12, fontWeight: 700, color: active ? C.text : C.textMuted }}>{sug.label}</div><div style={{ fontSize: 9, color: C.textDim, marginTop: 1 }}>{sug.sub}</div></div>
                  </div>
                  <div style={{ paddingTop: 8, borderTop: `1px solid ${active ? C.border : C.surface}`, display: "flex", flexDirection: "column", gap: 4 }}>
                    {bls.length > 0 && <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "0.5px", minWidth: 50 }}>Boosts</span>
                      <span style={{ fontSize: 11, fontWeight: 700, color: active ? C.text : C.textMuted }}>{bls.map(b => b.name).join(", ")}</span>
                    </div>}
                    {fl && <>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "0.5px", minWidth: 50 }}>Flavour</span>
                        <span style={{ fontSize: 12, fontWeight: 700, color: active ? C.text : C.textMuted }}>{fl.name}</span>
                        <span style={{ fontSize: 9, color: C.textDim }}>{fl.fn}</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "0.5px", minWidth: 50 }}>Contains</span>
                        <BadgeGroup codes={fl.codes} />
                      </div>
                    </>}
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "0.5px", minWidth: 50 }}>Serve</span>
                      <span style={{ fontSize: 11, color: C.textDim }}>{sug.volume}ml · {sug.waterType.replace("_", " ")}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        <div style={{ padding: "12px 28px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "flex-end" }}>
          <button onClick={() => selected !== null && onDispense(buildConfig(suggestions[selected]))} disabled={selected === null} style={{ fontFamily: "system-ui", background: selected !== null ? C.primaryBg : C.card, color: selected !== null ? C.primaryText : C.textDim, border: "none", borderRadius: 100, padding: "9px 30px", cursor: selected !== null ? "pointer" : "default", fontSize: 12, fontWeight: 700, opacity: selected !== null ? 1 : 0.4 }}>Dispense this →</button>
        </div>
      </div>
    </div>
  );
}

// ═══════════ QUICK SELECT ═══════════
function QuickSelect({ onDispense, onBack }) {
  const C = useC();
  const [boosts, setBoosts] = useState([]);
  const [flavorId, setFlavorId] = useState(null);
  const [waterType, setWaterType] = useState("chilled");
  const [volume, setVolume] = useState(500);
  const toggleBoost = (id) => setBoosts(s => s.includes(id) ? s.filter(x => x !== id) : s.length < 2 ? [...s, id] : s);
  const boostLayers = boosts.map(id => BOOSTS.find(b => b.id === id)).filter(Boolean);
  const flavorObj = FLAVORS.find(f => f.id === flavorId);

  return (
    <div style={{ width: "100%", height: "100%", background: C.bg, display: "flex", fontFamily: "system-ui, sans-serif", overflow: "hidden" }}>
      <div style={{ width: "40%", display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 14px", background: C.surface, overflow: "auto", borderRight: `1px solid ${C.border}` }}>
        {!flavorObj && boosts.length === 0 ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
            <GlassViz boostLayers={[]} flavorObj={null} waterType={waterType} volume={volume} animPhase={0} />
            <div style={{ fontSize: 11, color: C.textDim, marginTop: 8 }}>Pick boosts or flavour<br />to preview your drink</div>
          </div>
        ) : (
          <>
            <GlassViz boostLayers={boostLayers} flavorObj={flavorObj} waterType={waterType} volume={volume} animPhase={2} />
            {flavorObj && <div style={{ marginTop: 5, padding: "4px 12px", background: C.bg, border: `1px solid ${C.borderActive}`, borderRadius: 100, fontSize: 10, fontWeight: 700, color: C.text }}>{flavorObj.name} — {flavorObj.fn}</div>}
            <div style={{ marginTop: 6, width: "100%" }}><BenefitCards boostLayers={boostLayers} flavorObj={flavorObj} /></div>
          </>
        )}
      </div>
      <div style={{ width: "60%", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 28px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", color: C.textMuted, cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "system-ui" }}>← Back</button>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px" }}>Quick select</div>
        </div>
        <div style={{ flex: 1, padding: "10px 28px", overflow: "auto" }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 5 }}>Boosts <span style={{ fontWeight: 400 }}>(max 2)</span></div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 5, marginBottom: 12 }}>
            {BOOSTS.map(b => { const on = boosts.includes(b.id); return <button key={b.id} onClick={() => toggleBoost(b.id)} style={{ fontFamily: "system-ui", background: on ? C.card : "transparent", border: `1px solid ${on ? C.borderActive : C.border}`, borderRadius: 8, padding: "8px 4px", cursor: "pointer", textAlign: "center" }}><div style={{ fontSize: 10, fontWeight: 700, color: on ? C.text : C.textMuted }}>{b.name}</div><div style={{ marginTop: 3, display: "flex", justifyContent: "center" }}><BadgeGroup codes={b.codes} /></div></button>; })}
          </div>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 5 }}>Flavour</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 5, marginBottom: 12 }}>
            {FLAVORS.map(f => <button key={f.id} onClick={() => setFlavorId(f.id)} style={{ fontFamily: "system-ui", background: flavorId === f.id ? C.card : "transparent", border: `1px solid ${flavorId === f.id ? C.borderActive : C.border}`, borderRadius: 8, padding: "8px 4px", cursor: "pointer", textAlign: "center" }}><div style={{ fontSize: 10, fontWeight: 700, color: flavorId === f.id ? C.text : C.textMuted }}>{f.name}</div><div style={{ fontSize: 8, color: C.textDim }}>{f.fn}</div><div style={{ marginTop: 3, display: "flex", justifyContent: "center" }}><BadgeGroup codes={f.codes} /></div></button>)}
          </div>
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ flex: 1 }}><div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 5 }}>Water</div><div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 4 }}>{WATER_TYPES.map(w => <button key={w.id} onClick={() => setWaterType(w.id)} style={{ fontFamily: "system-ui", background: waterType === w.id ? C.card : "transparent", border: `1px solid ${waterType === w.id ? C.borderActive : C.border}`, borderRadius: 6, padding: "5px 4px", cursor: "pointer", fontSize: 10, fontWeight: waterType === w.id ? 700 : 500, color: waterType === w.id ? C.text : C.textMuted, textAlign: "center" }}>{w.label}</button>)}</div></div>
            <div><div style={{ fontSize: 10, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 5 }}>Volume</div><div style={{ display: "flex", gap: 6 }}>{VOLUMES.map(v => <button key={v.ml} onClick={() => setVolume(v.ml)} style={{ fontFamily: "system-ui", width: 44, height: 44, borderRadius: "50%", background: volume === v.ml ? C.card : "transparent", border: `1px solid ${volume === v.ml ? C.borderActive : C.border}`, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}><span style={{ fontSize: 10, fontWeight: 700, color: volume === v.ml ? C.text : C.textMuted }}>{v.ml >= 1000 ? "1L" : v.ml}</span></button>)}</div></div>
          </div>
        </div>
        <div style={{ padding: "12px 28px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "flex-end" }}>
          <button onClick={() => flavorId && onDispense({ boosts, boostLayers, flavor: flavorObj, waterType, volume })} disabled={!flavorId} style={{ fontFamily: "system-ui", background: flavorId ? C.primaryBg : C.card, color: flavorId ? C.primaryText : C.textDim, border: "none", borderRadius: 100, padding: "9px 30px", cursor: flavorId ? "pointer" : "default", fontSize: 12, fontWeight: 700, opacity: flavorId ? 1 : 0.4 }}>Dispense →</button>
        </div>
      </div>
    </div>
  );
}

// ═══════════ DISPENSING — outcome + vitamin name reveals ═══════════
function Dispensing({ config, onDone }) {
  const C = useC();
  const [progress, setProgress] = useState(0);
  const [visibleBoosts, setVisibleBoosts] = useState(0);
  const [showVitamins, setShowVitamins] = useState(false);
  const [visibleVits, setVisibleVits] = useState(0);

  useEffect(() => { const t = setInterval(() => setProgress(p => { if (p >= 100) { clearInterval(t); return 100; } return p + 1; }), 50); return () => clearInterval(t); }, []);

  const boostLayers = (config.boostLayers || config.boosts?.map(id => BOOSTS.find(b => b.id === id)) || []).filter(Boolean);
  const flavorObj = config.flavor;
  const done = progress >= 100;

  useEffect(() => {
    if (visibleBoosts < boostLayers.length) {
      const t = setTimeout(() => setVisibleBoosts(v => v + 1), 600);
      return () => clearTimeout(t);
    } else if (!showVitamins && boostLayers.length === visibleBoosts) {
      const t = setTimeout(() => setShowVitamins(true), 800);
      return () => clearTimeout(t);
    }
  }, [visibleBoosts, boostLayers.length, showVitamins]);

  useEffect(() => {
    if (showVitamins && flavorObj && visibleVits < flavorObj.vitamins.length) {
      const t = setTimeout(() => setVisibleVits(v => v + 1), 600);
      return () => clearTimeout(t);
    }
  }, [showVitamins, visibleVits, flavorObj]);

  return (
    <div style={{ width: "100%", height: "100%", background: C.bg, display: "flex", fontFamily: "system-ui, sans-serif" }}>
      {/* Left: glass + summary */}
      <div style={{ width: 260, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "14px 14px", borderRight: `1px solid ${C.border}`, flexShrink: 0, gap: 5 }}>
        <div style={{ fontSize: done ? 15 : 12, fontWeight: 700, color: C.text, transition: "all 0.3s" }}>{done ? "Ready!" : `Pouring... ${progress}%`}</div>
        <GlassViz boostLayers={boostLayers} flavorObj={flavorObj} waterType={config.waterType} volume={config.volume} animPhase={2} fillProgress={progress} />
        <div style={{ marginTop: 4, textAlign: "center" }}>
          {flavorObj && <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{flavorObj.name} — {flavorObj.fn}</div>}
          {boostLayers.length > 0 && <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>+ {boostLayers.map(b => b.name).join(", ")}</div>}
          <div style={{ fontSize: 9, color: C.textDim, marginTop: 2 }}>{config.volume}ml · {config.waterType.replace("_", " ")}</div>
        </div>
        {done && <button onClick={onDone} style={{ fontFamily: "system-ui", marginTop: 6, background: C.primaryBg, color: C.primaryText, border: "none", borderRadius: 100, padding: "10px 30px", cursor: "pointer", fontSize: 13, fontWeight: 700 }}>Done</button>}
      </div>
      {/* Right: staggered benefit reveals — outcome paired with vitamin name */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: "16px 24px", overflow: "auto" }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: C.text, marginBottom: 2 }}>{done ? "Enjoy your drink" : "Crafting your drink"}</div>
        <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 12 }}>Here's what's working for you</div>

        {/* Boost reveals — first */}
        {boostLayers.length > 0 && <>
          <div style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 6 }}>Your boosts</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5, marginBottom: 12 }}>
            {boostLayers.map((b, i) => (
              <div key={b.id} style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "7px 10px", background: C.card, border: `1px solid ${C.borderActive}`, borderRadius: 8, opacity: i < visibleBoosts ? 1 : 0, transform: i < visibleBoosts ? "translateY(0)" : "translateY(6px)", transition: "all 0.5s" }}>
                <div style={{ width: 16, height: 16, borderRadius: 3, border: `1px solid ${C.borderActive}`, background: C.surface, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}><span style={{ fontSize: 9, fontWeight: 800, color: C.text }}>+</span></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: C.text, marginBottom: 2 }}>{b.dispenseBenefit}</div>
                  <BadgeGroup codes={b.codes} />
                </div>
              </div>
            ))}
          </div>
        </>}

        {/* Flavor vitamin + botanical reveals — secondary "plus you're also getting" */}
        {showVitamins && flavorObj && <>
          <div style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", letterSpacing: "1px", marginBottom: 6, transition: "opacity 0.5s" }}>{boostLayers.length > 0 ? `Plus, you're also getting — ${flavorObj.fn}` : `Your ${flavorObj.fn} vitamins & botanicals`}</div>
          <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 8, lineHeight: "16px" }}>{flavorObj.dispenseBenefit}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            {flavorObj.vitamins.map((v, i) => (
              <div key={v.code} style={{ display: "flex", gap: 8, alignItems: "center", padding: "6px 10px", background: C.card, border: `1px solid ${v.botanical ? C.borderLight : C.border}`, borderRadius: 8, opacity: i < visibleVits ? 1 : 0, transform: i < visibleVits ? "translateY(0)" : "translateY(6px)", transition: "all 0.5s" }}>
                <Badge label={v.code} />
                <div style={{ fontSize: 10, color: C.textMuted, lineHeight: "13px", fontStyle: v.botanical ? "italic" : "normal" }}>{v.benefit}</div>
              </div>
            ))}
          </div>
        </>}

        <div style={{ flex: 1 }} />
        {done && <div style={{ marginTop: 10, padding: "10px 12px", background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, display: "flex", alignItems: "flex-start", gap: 10 }}>
          <span style={{ fontSize: 15, marginTop: 1 }}>📱</span>
          <div><div style={{ fontSize: 11, fontWeight: 700, color: C.text }}>Your drink, but smarter</div><div style={{ fontSize: 10, color: C.textMuted, marginTop: 2, lineHeight: "13px" }}>With the app, we'd adjust your boosts and vitamins based on your health data.</div></div>
        </div>}
      </div>
    </div>
  );
}

// ═══════════ APP ROUTER ═══════════
export default function App() {
  const [screen, setScreen] = useState("saver");
  const [dispenseConfig, setDispenseConfig] = useState(null);
  const [dark, setDark] = useState(false);
  const theme = dark ? DARK : LIGHT;
  C = theme;
  const reset = () => { setScreen("saver"); setDispenseConfig(null); };
  const goDispense = (cfg) => { setDispenseConfig(cfg); setScreen("dispensing"); };
  return (
    <ThemeContext.Provider value={theme}>
      <div style={{ width: "100%", maxWidth: 1024, aspectRatio: "4 / 3", margin: "0 auto", background: theme.bg, overflow: "hidden", position: "relative" }}>
        {screen === "saver" && <Screensaver onTap={() => setScreen("entry")} />}
        {screen === "entry" && <EntryChoice onCraft={() => setScreen("craft")} onSuggested={() => setScreen("suggested")} onQuickSelect={() => setScreen("quick")} />}
        {screen === "craft" && <CraftBuilder onDispense={goDispense} onBack={() => setScreen("entry")} />}
        {screen === "suggested" && <SuggestedDrink onDispense={goDispense} onBack={() => setScreen("entry")} />}
        {screen === "quick" && <QuickSelect onDispense={goDispense} onBack={() => setScreen("entry")} />}
        {screen === "dispensing" && dispenseConfig && <Dispensing config={dispenseConfig} onDone={reset} />}
        <button onClick={() => setDark(d => !d)} style={{ position: "absolute", top: 12, right: 12, zIndex: 50, width: 34, height: 34, borderRadius: "50%", background: theme.card, border: `1px solid ${theme.borderLight}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontFamily: "system-ui", color: theme.text }}>
          {dark ? "☀" : "☾"}
        </button>
      </div>
    </ThemeContext.Provider>
  );
}
